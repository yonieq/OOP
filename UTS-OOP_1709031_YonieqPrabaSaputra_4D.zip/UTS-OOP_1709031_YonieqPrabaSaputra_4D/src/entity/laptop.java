package entity;

/**
 *
 * @author yonieq
 */
public class laptop {
    private String id;
    private String nama;
    private String merk_laptop;
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getNama() {
        return nama;
    }
    
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public String setMerk_laptop() {
        return merk_laptop;
    }
    
    public void setMerk_laptop(String merk_laptop) {
        this.merk_laptop = merk_laptop;
    }
    
    public laptop(String id, String nama, String merk_laptop) {
        this.id = id;
        this.nama = nama;
        this.merk_laptop = merk_laptop;
    }
    
    public boolean equals(Object object) {
        laptop temp = (laptop) object;
        return id.equals(temp.getId());
    }
}
