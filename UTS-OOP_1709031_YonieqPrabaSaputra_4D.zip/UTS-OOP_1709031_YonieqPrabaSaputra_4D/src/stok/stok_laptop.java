package stok;

import java.util.*;
import entity.*;
/**
 *
 * @author yonieq
 */
public class stok_laptop {
    
    private static List<laptop> data = new LinkedList<laptop>();
    
    public void addData(laptop lp) {
        data.add(lp);
        System.out.println("Selamat Data Telah diSimpan");
    }
    
    public void updateData(laptop lp){
        int index = data.indexOf(lp);
        if (index >= 0 ) {
        
        data.set(index, lp);
        System.out.println("Selamat Data Telah diUbah");
        }
    }
    
    public void deleteData(String id){
        int idx = data.indexOf(new laptop(id, "", ""));
        if(idx >=0) {
            data.remove(idx);
            System.out.println("Selamat Data Telah diHapus");
        }
    }
    
    public void showAllData() {
        int i=1;
        System.out.println("\nData Dalam Daftar");
        for(laptop lp : data) {
            System.out.println("data ke-"+ i++);
            System.out.println("ID : " + lp.getId());
            System.out.println("Nama : " + lp.getNama());
            System.out.println("MERK LAPTOP : " + lp.setMerk_laptop());
        }
    }
}
