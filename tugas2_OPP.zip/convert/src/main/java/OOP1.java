public class OOP1 {
}

import java.awt.*;

import javax.swing.*;

import javax.swing.border.*;

import java.awt.event.*;

public class Convert extends JFrame implements ActionListener{



    // private static final Logger logger = LogManager.getRootLogger(convert.class);







    JButton btnHitung = new JButton("Hitung");

    JButton btnClear = new JButton("Clear");

    float pilihan1,pilihan2,besaran_input,besaran_keluaran,nilai_input,hasil;

    String arrBesaran[] = {"Meter", "Centimeter", "Milimeter", "Inchi", "Kilometer"};

    JTextField jtfi_input = new JTextField("");

    JLabel jlblHasil = new JLabel("Hasil : ");

    JComboBox cmbBesaran1 = new JComboBox (arrBesaran);

    JComboBox cmbBesaran2 = new JComboBox (arrBesaran);

    float konv_inchi;



    //konstruktor

    public Convert() {

        //konfigurasi komponen

        jlblHasil.setForeground(Color.BLACK);

        jtfi_input.setEditable(true);

        jtfi_input.setColumns(6);

        btnHitung.setToolTipText("Hitung Nilai");

        btnClear.setToolTipText("Hapus Field");

        cmbBesaran1.setMaximumRowCount(5);

        cmbBesaran2.setMaximumRowCount(5);





        //event item listener untuk combobox

        cmbBesaran1.addItemListener(

                new ItemListener() {

                    public void itemStateChanged (ItemEvent e) {

                        if (e.getStateChange() == ItemEvent.SELECTED){

                            pilihan1 = cmbBesaran1.getSelectedIndex();

                        }

                    }

                } //akhir inner class

        );



        //event item listener untuk combobox

        cmbBesaran2.addItemListener(

                new ItemListener() {

                    public void itemStateChanged (ItemEvent e) {

                        if (e.getStateChange() == ItemEvent.SELECTED){

                            pilihan2 = cmbBesaran2.getSelectedIndex();



                        }

                    }

                } //akhir inner class

        );





        // Panel 1

        JPanel p1 = new JPanel(new GridLayout(1, 2, 10, 10));

        Font largeFont = new Font("TimesRoman", Font.BOLD, 20);

        Border lineBorder = new LineBorder(Color.BLACK, 2);

        p1.add(jtfi_input);

        p1.add(cmbBesaran1);

        p1.add(jlblHasil);

        p1.add(cmbBesaran2);

        p1.setBorder(new TitledBorder("Input dan Hasil"));



        // Panel 2

        JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));

        p2.add(btnHitung);

        p2.add(btnClear);



        // tambahkan kedua panel kedalam frame

        setLayout(new GridLayout(2, 1, 5, 5));

        add(p1);

        add(p2);



        //Injeksi Event di Komponen

        btnHitung.addActionListener(this);//tambahkan event disini

        btnClear.addActionListener(this);//tambahkan event disini

    }





    //pengaturan aksi setiap event

    public void actionPerformed( ActionEvent event){

        if ( event.getSource() == btnHitung ){

            //ambil info nilai yg diinput

            besaran_input = pilihan1;

            besaran_keluaran = pilihan2;

            nilai_input  = Float.parseFloat(jtfi_input.getText());

            konv_inchi = 24 / 10; //2.4



            //logika rumus meter to all

            if ((besaran_input == 0)&&(besaran_keluaran == 1)){

                //untuk meter ke centimeter

                hasil = nilai_input * 100;

            } else if ((besaran_input == 0)&&(besaran_keluaran == 2)){

                //untuk meter ke milimeter

                hasil = nilai_input * 1000;

            } else if ((besaran_input == 0)&&(besaran_keluaran == 3)){

                //untuk meter ke inchi, 1 inchi = 2,45 cm

                hasil = (nilai_input * 100);

                hasil =  hasil / konv_inchi;

            } else if ((besaran_input == 0)&&(besaran_keluaran == 4)){

                //untuk meter ke kilometer

                hasil = nilai_input / 1000;

            }



            //logika rumus centimeter to all

            else if ((besaran_input == 1)&&(besaran_keluaran == 0)){

                //untuk centimeter ke meter

                hasil = nilai_input / 100;

            } else if ((besaran_input == 1)&&(besaran_keluaran == 2)){

                //untuk centimeter ke milimeter

                hasil = nilai_input * 10;

            } else if ((besaran_input == 1)&&(besaran_keluaran == 3)){

                //untuk centimeter ke inchi

                hasil = nilai_input / konv_inchi;

            } else if ((besaran_input == 1)&&(besaran_keluaran == 4)){

                //untuk centimeter ke kilometer

                hasil = nilai_input / 100000;

            }



            //logika rumus milimeter to all

            else if ((besaran_input == 2)&&(besaran_keluaran == 0)){

                //untuk milimeter ke meter

                hasil = nilai_input / 1000;

            } else if ((besaran_input == 2)&&(besaran_keluaran == 1)){

                //untuk milimeter ke centimeter

                hasil = nilai_input / 10;

            } else if ((besaran_input == 2)&&(besaran_keluaran == 3)){

                //untuk milimeter ke inchi

                hasil = (nilai_input / 10);

                hasil = hasil / konv_inchi;

            } else if ((besaran_input == 2)&&(besaran_keluaran == 4)){

                //untuk milimeter ke kilometer

                hasil = nilai_input / 1000000;

            }



            //logika rumus inchi to all

            else if ((besaran_input == 3)&&(besaran_keluaran == 0)){

                //untuk inchi ke meter

                hasil = (nilai_input * konv_inchi);

                hasil = hasil / 100 ;

            } else if ((besaran_input == 3)&&(besaran_keluaran == 1)){

                //untuk inchi ke centimeter

                hasil = (nilai_input * konv_inchi);

            } else if ((besaran_input == 3)&&(besaran_keluaran == 2)){

                //untuk inchi ke milimeter

                hasil = (nilai_input * konv_inchi);

                hasil = hasil * 10;

            } else if ((besaran_input == 3)&&(besaran_keluaran == 4)){

                //untuk inchi ke kilometer

                hasil = (nilai_input * konv_inchi);

                hasil = hasil / 100000;

            }



            //logika rumus kilometer to all

            else if ((besaran_input == 4)&&(besaran_keluaran == 0)){

                //untuk kilometer ke meter

                hasil = nilai_input * 1000;

            } else if ((besaran_input == 4)&&(besaran_keluaran == 1)){

                //untuk kilometer ke centimeter

                hasil = nilai_input * 100000;

            } else if ((besaran_input == 4)&&(besaran_keluaran == 2)){

                //untuk kilometer ke milimeter

                hasil = nilai_input * 1000000;

            } else if ((besaran_input == 4)&&(besaran_keluaran == 3)){

                //untuk kilometer ke inchi

                hasil = (nilai_input * 100000);

                hasil = hasil / konv_inchi;

            }



            //tampilkan hasil perhitungan

            jlblHasil.setText(Float.toString(hasil));

            //bersihkan semua

            hasil = 0;

            besaran_input = 0;

            besaran_keluaran = 0;



        } else if ( event.getSource() == btnClear ){

            jtfi_input.setText("");

            jlblHasil.setText("Hasil : ");



        }

    }



}
